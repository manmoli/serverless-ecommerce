import { APIGatewayEvent } from 'aws-lambda';
export declare const handler: (event: APIGatewayEvent) => Promise<{
    statusCode: number;
    body: string;
}>;
