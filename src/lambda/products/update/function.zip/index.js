"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const AWS = __importStar(require("aws-sdk"));
const validators_1 = require("./util/validators");
const product_dto_1 = require("./product.dto");
const dynamoDb = new AWS.DynamoDB.DocumentClient();
const s3 = new AWS.S3();
const tableName = (_a = process.env.PRODUCT_TABLE_NAME) !== null && _a !== void 0 ? _a : '';
const bucketName = process.env.PRODUCT_BUCKET_NAME;
const handler = (event) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        console.log(event.body);
        const body = JSON.parse(event.body ? event.body : '{}');
        const errors = yield (0, validators_1.validateObject)(product_dto_1.UpdateProductDTO, body);
        if (errors.length) {
            return {
                statusCode: 400,
                body: JSON.stringify({
                    message: 'Invalid parameters.',
                    errors
                })
            };
        }
        const updateExpressions = [];
        const expressionAttributes = {};
        if (body.imageBase64) {
            const imageKey = `${body.productId}.${body.imageType}`;
            const s3Params = {
                Bucket: bucketName !== null && bucketName !== void 0 ? bucketName : '',
                Key: imageKey,
                Body: Buffer.from(body.imageBase64, 'base64'),
                ContentType: `image/${body.imageType}`
            };
            yield s3.upload(s3Params).promise();
            const imageUrl = `https://${bucketName}.s3.amazonaws.com/${imageKey}`;
            expressionAttributes[':imageUrl'] = imageUrl;
            updateExpressions.push('imageUrl = :imageUrl');
        }
        delete body.imageBase64;
        delete body.imageType;
        Object.keys(body).forEach(key => {
            const expressionAttributeValue = `:${key}`;
            expressionAttributes[expressionAttributeValue] = body[key];
            updateExpressions.push(`${key} = ${expressionAttributeValue}`);
        });
        dynamoDb.update({
            TableName: tableName,
            Key: { productId: body.productId },
            UpdateExpression: `set ${updateExpressions.join(',')}`,
            ExpressionAttributeValues: expressionAttributes,
        });
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'Product updated correctly',
                body
            })
        };
    }
    catch (error) {
        console.error('Error creating product:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Failed to create product',
                error: error.message,
            }),
        };
    }
});
exports.handler = handler;
