export declare const handler: (event: import("aws-lambda").APIGatewayProxyEvent) => Promise<{
    statusCode: number;
    body: string;
}>;
